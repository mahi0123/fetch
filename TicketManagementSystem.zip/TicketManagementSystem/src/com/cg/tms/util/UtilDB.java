package com.cg.tms.util;



import java.util.*;



public class UtilDB {



 private static Map<String,String> ticketCategory=new HashMap<String,String>();

 public static Map<String,String> getTicketCategoryEntries()

 {

 ticketCategory.put("tc001", "Software Installation");

 ticketCategory.put("tc002", "Mailbox Creation");

 ticketCategory.put("tc003", "MailBox Issues");





 return ticketCategory;



 }

}

