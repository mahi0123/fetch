package com.cg.tms.exception;

public class TicketException extends Exception {
	
	TicketException()
	{}
	public TicketException(String msg)
	{
		super(msg);
	}

}
