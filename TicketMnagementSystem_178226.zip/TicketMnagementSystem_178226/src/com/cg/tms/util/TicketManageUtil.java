package com.cg.tms.util;

import java.util.HashMap;
import java.util.Map;

import com.cg.tms.dto.TicketCategory;

public class TicketManageUtil {
	
	private static Map<String, TicketCategory> ticketCategory=new HashMap();
	static TicketCategory t=new TicketCategory("tc001","software installation" );
	static TicketCategory t1=new TicketCategory("tc002","mailbox creation" );
	static TicketCategory t2=new TicketCategory("tc003","mailbox issues" );
	public static Map<String,TicketCategory>getTicketCategoryEntries()
	{
		
		
		ticketCategory.put(t.getTicketCategoryId(),t);
		ticketCategory.put(t1.getTicketCategoryId(),t1);
		ticketCategory.put(t2.getTicketCategoryId(),t2);
		return ticketCategory;
		
	}

}
