package com.cg.tms.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import com.cg.tms.dao.ITicketManagementDao;
import com.cg.tms.dao.TicketManagementImplDao;
import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;


public class TicketManagementImpl implements ITicketMnageService {
	public boolean b;
	ITicketManagementDao idao=null;
	private int generateTicketNo(){
		Random rd=new Random();
		return  rd.nextInt(100000);
	}	
	
	@Override
	public Map<Integer, TicketBean> riseNewTicket(TicketBean ticketBean) {
		idao=new TicketManagementImplDao();
		ticketBean.setDate(LocalDate.now());
		ticketBean.setTicketNo(generateTicketNo());
		//System.out.println(ticketBean+"--------");
		return idao.riseNewTicket(ticketBean);	
	}
	@Override
	public HashMap<String,TicketCategory> listTicketCategory() 
	{
		idao=new TicketManagementImplDao();
		
		return idao.listTicketCategory();
	}
	public void validationTicketCategory( int ticketCategory)
	{
		if(ticketCategory<=3 &&ticketCategory>0)
		{
			b=true;
		}
		else
		{
			b=false;
		}
	}
	public void validationTicketPriority( int ticketPriority)
	{
		if(ticketPriority<=3 &&ticketPriority>0)
		{
			b=true;
		}
		else
		{
			b=false;
		}
	}

}
