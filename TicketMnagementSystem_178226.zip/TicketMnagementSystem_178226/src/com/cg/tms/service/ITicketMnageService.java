package com.cg.tms.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;

public interface ITicketMnageService {
	Map<Integer, TicketBean> riseNewTicket(TicketBean ticketBean);
	HashMap<String,TicketCategory>listTicketCategory();
}
