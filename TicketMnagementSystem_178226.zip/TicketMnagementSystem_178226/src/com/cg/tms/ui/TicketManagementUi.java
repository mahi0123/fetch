package com.cg.tms.ui;

import java.util.HashMap;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import com.cg.tms.dao.TicketManagementImplDao;
import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.exception.TicketException;
import com.cg.tms.service.ITicketMnageService;
import com.cg.tms.service.TicketManagementImpl;
//------------------------ 1. Ticket Management System --------------------------
	/*******************************************************************************************************
	 - Function Name	:	TicketManagementSystem
	 - Input Parameters	:	Ticket object
	 - Return Type		:	String 
	 - Throws		:  		TicketManagementException
	 - Author		:	CAPGEMINI
	 - Creation Date	:	19/04/2019
	 - Description		:	adding ticketno to database calls dao method ticketraised details
	 ********************************************************************************************************/

public class TicketManagementUi {
	static TicketCategory ticbe2=new TicketCategory();
	static TicketBean ticketBean =new TicketBean();
	static ITicketMnageService ith=null;
 static	TicketManagementImpl tmi=new TicketManagementImpl ();

	static Scanner scan =new Scanner(System.in);
	public static void main(String[] args) {
		System.out.println("---Welcomr to ITIMD Help Desk---");
		System.out.println("1. Raise a Ticket \n 2. Exit from the System");
		System.out.println("Select the category from  above :");
		switch(scan.nextInt())
		{
		case 1:
			System.out.println("you selected an option to raise a ticket");
			user();
			break;
		case 2:
			System.out.println("you selected an opton to exit");
			exits();
			break;
			default:
				System.out.println("please enter valid option");
		}
	}
	static void exits()
	{
		System.out.println("you are out of the system");
		
	}
	
	
	static void user()
	{
		System.out.println("select Ticket category from below List:");
		System.out.println("to select enter 1 to 3 numbers :");
		ith=new TicketManagementImpl();
		HashMap<String,TicketCategory> ticketcategory=ith.listTicketCategory();
		Set r=ticketcategory.entrySet();
		r.stream().forEach(System.out::println);
		riseNewTicket( );
			
		}
	
	
	static void riseNewTicket( )
	{
	do
	{
	int ticketCategory=scan.nextInt();
	switch (ticketCategory)
	{
	case 1:
		System.out.println("your ticket was selected ");
		break;
	case 2:System.out.println("your ticket was selected ");
		break;
	case 3:System.out.println("your ticket was selected ");
		break;
		default :System.out.println("enter proper number ");
	}
	tmi.validationTicketCategory(ticketCategory);
	}while(tmi.b==false);
	String ticketPriority = null;
	do
	{
	
	
	System.out.println("Enter priority(1.low  2.medium  3.high)");
	int ticketPrioritys=scan.nextInt();
	switch(ticketPrioritys)
	{
	case 1:
		System.out.println("your selected priority was : low");
		break;
	case 2:System.out.println("your selected priority was :  medium");
		break;
	case 3:System.out.println("your selected priority was :  high");
		break;
		
	}
	if(ticketPrioritys==1)
	{
		ticketPriority="low";
	}
	else if(ticketPrioritys==2)
	{
		ticketPriority="medium";	
	}
	else if(ticketPrioritys==3)
	{
		ticketPriority="high";
	}
	else
	{
		System.out.println("select proper priority");
	}
	tmi.validationTicketPriority(ticketPrioritys);
	}while(tmi.b==false);
	
	String ticketStatus;
	System.out.println("enter ticket status :");
	ticketStatus=scan.next();
	String ticketDescription = null;
	System.out.println("enter ticket description :");
	ticketStatus=scan.next();
	String ticketCategoryId=ticbe2.getTicketCategoryId();
	
	TicketBean ticb=new TicketBean(ticketCategoryId, ticketDescription, ticketPriority, ticketStatus);
	ith=new TicketManagementImpl();
//	ith.riseNewTicket(ticketBean);
	
	try{
	if(ith.riseNewTicket(ticketBean)!=null)
	{
		System.out.println("Your ticket was raised ");
		System.out.println(TicketManagementImplDao.accountlist);
		System.out.println(" if you want to continue enter yes if you want to exit enter no ");
		String s="";
		do
		{
		 s=scan.next();
		if(s.equalsIgnoreCase("yes"))
		{
			user();
		}
		else if (s.equalsIgnoreCase("no"))
		{
			exits();
		}
		}while(s.equalsIgnoreCase("yes") || s.equalsIgnoreCase("no"));
	}
	else throw new TicketException("you went wrong");
	}
	catch(TicketException e)
	{
		System.out.println("exception occured"+e);
	}
	
	}

}
