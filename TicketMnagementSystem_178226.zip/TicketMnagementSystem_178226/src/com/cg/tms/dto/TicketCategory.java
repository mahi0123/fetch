package com.cg.tms.dto;




public class TicketCategory {
	private String TicketCategoryId;
	private String CategoryName;
	public String getTicketCategoryId() {
		return TicketCategoryId;
	}
	public void setTicketCategoryId(String ticketCategoryId) {
		TicketCategoryId = ticketCategoryId;
	}
	public String getCategoryName() {
		return CategoryName;
	}
	public void setCategoryName(String categoryName) {
		CategoryName = categoryName;
	}
	public TicketCategory(String ticketCategoryId, String categoryName) {
		super();
		TicketCategoryId = ticketCategoryId;
		CategoryName = categoryName;
	}
	public TicketCategory() {
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		
		return this.CategoryName;
	}
	
	}

