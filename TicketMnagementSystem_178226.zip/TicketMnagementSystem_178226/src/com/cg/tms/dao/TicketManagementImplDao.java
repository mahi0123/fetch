package com.cg.tms.dao;
import java.util.HashMap;
import java.util.Map;
import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.util.TicketManageUtil;

public class TicketManagementImplDao implements ITicketManagementDao {
	public static Map<Integer, TicketBean> accountlist=new HashMap<Integer, TicketBean>();
	@Override
	public Map<Integer, TicketBean> riseNewTicket(TicketBean ticketBean) 
	{
		accountlist.put(ticketBean.getTicketNo(),ticketBean);
		//System.out.println(accountlist.get(ticketBean.getTicketNo()));
		return accountlist;
	}

	@Override
	public HashMap<String,TicketCategory> listTicketCategory() 
	{
		return (HashMap<String, TicketCategory>) TicketManageUtil.getTicketCategoryEntries();
	}

}
