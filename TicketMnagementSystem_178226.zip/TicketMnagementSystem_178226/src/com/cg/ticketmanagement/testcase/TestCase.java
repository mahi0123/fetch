package com.cg.ticketmanagement.testcase;


import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.cg.tms.dao.ITicketManagementDao;
import com.cg.tms.dao.TicketManagementImplDao;
import com.cg.tms.dto.TicketBean;



public class TestCase {
	
		
		ITicketManagementDao irao=null;
		@Before
		public void init() {
			irao= new  TicketManagementImplDao();
			
		}
		@After
		public void destroy() {
			irao=null;
		}

	@Test
	public void TestTicket() {
		TicketBean e=new TicketBean();
		e.getTicketNo();
		Assert.assertNotNull(e);
	}

	}
