package com.cg.cms.dao;

import java.util.List;

import com.cg.cms.dto.CabBean;
import com.cg.cms.dto.CabCategory;
import com.cg.cms.exception.CabManagementException;

public interface CabDAO {

	boolean bookCab(CabBean cabBean) throws CabManagementException;
	List<CabCategory> listCabCategory() throws CabManagementException;
}
