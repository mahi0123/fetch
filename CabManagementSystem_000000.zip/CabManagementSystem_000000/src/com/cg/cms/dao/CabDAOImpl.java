package com.cg.cms.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.cg.cms.dto.CabBean;
import com.cg.cms.dto.CabCategory;
import com.cg.cms.exception.CabManagementException;
import com.cg.cms.util.Util;

public class CabDAOImpl implements CabDAO {

	@Override
	public boolean bookCab(CabBean cabBean) throws CabManagementException {
		Map cabsBooked = Util.getCabsBooked();
		cabsBooked.put(cabBean.getCabNo(), cabBean);
		boolean confirmCabBooked = cabsBooked.containsKey(cabBean.getCabNo());
		if(confirmCabBooked)
		{
			System.out.println("Booked Cab : " + cabBean.getCabNo());
		}
		return confirmCabBooked;
	}

	@Override
	public List<CabCategory> listCabCategory() throws CabManagementException {
		//checking empty cat categories.
		if(Util.getcabCategoryEntries().isEmpty() || Util.getcabCategoryEntries() == null)
		{
			throw new CabManagementException("Cab Catetories are Empty!");
		}
		
		List cabCategoriesList = new ArrayList<CabCategory>();
		
		Map<String, String> cabCateogiesMap = Util.getcabCategoryEntries();
	    ArrayList<String> cabCategoriesKeyList = new ArrayList<String>(cabCateogiesMap.keySet());
	    ArrayList<String> cabCategoriesValueList = new ArrayList<String>(cabCateogiesMap.values());
	    	
		for(int index = 0; index<cabCategoriesKeyList.size();index++)
		{
			CabCategory cabCategory = new CabCategory(cabCategoriesKeyList.get(index),cabCategoriesValueList.get(index));
			cabCategoriesList.add(cabCategory);
		}
			
		return cabCategoriesList;
	}

}
