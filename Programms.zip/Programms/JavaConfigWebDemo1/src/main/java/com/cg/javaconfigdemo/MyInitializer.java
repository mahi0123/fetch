package com.cg.javaconfigdemo;

import javax.sql.rowset.WebRowSet;

public class MyInitializer 
{

}
