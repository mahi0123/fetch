package com.cg.jpademo1.app;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.cg.jpademo1.config.AppConfig;
import com.cg.jpademo1.entities.Movie;
import com.cg.jpademo1.services.MovieService;

public class Main {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = 
				new AnnotationConfigApplicationContext(AppConfig.class);
		MovieService service = context.getBean(MovieService.class);
		System.out.println("Creating new movie");
		Movie m1 = new Movie();
		m1.setBudget(12500000D);
		m1.setDirector("Sandeep");
		m1.setGenre("Romance");
		m1.setTitle("KabirSingh");
		m1.setId(10023);
		
		
		Movie m2 = new Movie();
		m2.setBudget(1250000000D);
		m2.setDirector("Avatar");
		m2.setGenre("Sci fi");
		m2.setTitle("James Cameron");
		m2.setId(25);
		

		service.save(m1);
		service.save(m2);
		System.out.println("Movie details "+m1.getTitle()+" by "+m1.getDirector());

		Movie m3 = service.findById(25);
		System.out.println("Movie found: "+m3.getTitle()+" budget: "+m3.getBudget());

	}


}
