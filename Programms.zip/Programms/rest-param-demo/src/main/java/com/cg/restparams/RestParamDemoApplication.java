package com.cg.restparams;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestParamDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestParamDemoApplication.class, args);
	}

}
