package com.cg.empapp.controllers;

import javax.servlet.http.HttpServletRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import com.cg.empapp.exception.ApplicationException;

@ControllerAdvice
public class MyExceptionMapper {

	@ExceptionHandler(value=ApplicationException.class)
	@ResponseBody
	protected ResponseEntity<String> handleError(ApplicationException ex, HttpServletRequest req){
	 
	 String message = ex.getMessage();
	 System.out.println("caught exception"+message);
	 String url= req.getRequestURI().toString();
	 System.out.println("error at "+url);
	 return new ResponseEntity<String>(message,HttpStatus.BAD_REQUEST);
	 
	}

}
