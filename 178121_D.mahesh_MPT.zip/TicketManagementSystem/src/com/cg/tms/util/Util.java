package com.cg.tms.util;

import java.util.HashMap;
import java.util.Map;

import javax.print.attribute.standard.RequestingUserName;

public class Util {

	 private static Map<String,String> ticketCategory=new HashMap<String,String>();

	 public static Map<String,String> getTicketCategoryEntries()
	 {

	 ticketCategory.put("tc001", "Software Installation");

	 ticketCategory.put("tc002", "Mailbox Creation");

	 ticketCategory.put("tc003", "MailBox Issues");

	 return ticketCategory;

	 }

	}










