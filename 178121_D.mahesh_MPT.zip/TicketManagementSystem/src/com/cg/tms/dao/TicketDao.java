package com.cg.tms.dao;

import java.util.List;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;

public interface TicketDao {
	
	boolean raiseNewTicket(TicketBean ticketBean);
	
	public TicketBean getTicketCategoryId(String ticketNo);
	
	List<TicketCategory>ListTicketCategory();
	
	
	
	

}








