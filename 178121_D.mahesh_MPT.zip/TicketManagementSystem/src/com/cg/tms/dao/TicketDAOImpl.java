package com.cg.tms.dao;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.util.Util;

public class TicketDAOImpl implements TicketDao{

	
	 Map<String, TicketBean> ticketLog = new HashMap<>();
	@Override
	public boolean raiseNewTicket(TicketBean ticketBean) {
		// TODO Auto-generated method stub
		 ticketLog.put(ticketBean.getTicketno(), ticketBean);
		 TicketBean ac1 = ticketLog.get(ticketBean.getTicketno());

		 if(ac1!=null)

		 return true;

		 else

		 return false;
	}

		

	@Override
	public TicketBean getTicketCategoryId(String ticketNo) {
		return null;
		// TODO Auto-generated method stub
		

	}

	@Override
	public List<TicketCategory> ListTicketCategory() {
		// TODO Auto-generated method stub
		
		 Collections c = (Collections) Util.getTicketCategoryEntries();

		 List<TicketCategory> tlist = (List<TicketCategory>) c;
		return tlist;

	
	}
		

}






