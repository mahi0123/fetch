package com.cg.tms.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDateTime;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.service.TicketService;
import com.cg.tms.util.Util;

public class MainUI {
	
	 static TicketService ticketService = null;

	 static TicketCategory tc = null;

	 static TicketBean ticketBean = null;

	 static BufferedReader br = null;

	 public static void main(String[] args) throws NumberFormatException, IOException {

	 // TODO Auto-generated method stub

	 br = new BufferedReader(new InputStreamReader(System.in));

	 System.out.println("\t\tWelcome to ITIMB Help Desk");

	 System.out.println("1.Raise a Ticket\n2.Exit");

	 int choice = Integer.parseInt(br.readLine());

	 switch(choice)

	 {

	 case 1:

	  System.out.println("Select Ticket Category from below List ");

	  Map<String,String> map = Util.getTicketCategoryEntries();

	  Set<String> keys = map.keySet();

	  int c=1;

	  boolean status = false;

	  for (Iterator i = keys.iterator(); i.hasNext(); ) {

	  String key = (String) i.next();

	  String value = (String) map.get(key);

	  tc = new TicketCategory(key,value);

	  System.out.println(c+"."+value);

	  c++;

	  }

	  System.out.print("Enter Option : ");

	  int op = Integer.parseInt(br.readLine());

	  switch(op)


	  {

	  case 1:

	  TicketBean tb = getData();

	  status = ticketService.raiseNewTicket(tb);

	  if(status)

	  System.out.println("Ticket Number "+ticketBean.getTicketno()+" logged Successfully at "+LocalDateTime.now());

	  else

	  ticketBean.setTicketStatus("Ticked Raise Failed");

	  break;

	  case 2:

	  TicketBean tb1 = getData();

	  status = ticketService.raiseNewTicket(tb1);

	  if(status)

	  System.out.println("Ticket Number "+ticketBean.getTicketno()+" logged Successfully at "+LocalDateTime.now());


	  else

	  ticketBean.setTicketStatus("Ticked Raise Failed");

	  break;

	  case 3:

	  TicketBean tb2 = getData();

	  status = ticketService.raiseNewTicket(tb2);

	  if(status)

	  System.out.println("Ticket Number "+ticketBean.getTicketno()+" logged Successfully at "+LocalDateTime.now());

	  else

	  ticketBean.setTicketStatus("Ticked Raise Failed");

	  break;

	  default:

	  System.out.println("Invalid Selection");

	  break;

	  }

	  break;

	 case 2:

	 System.exit(0);

	 break;

	 default :

	 System.out.println("Invaid Selection");


	 break;

	 }

	 }

	 private static String getPriority() throws IOException {

	 // TODO Auto-generated method stub

	 System.out.print("Enter Priority(1.Low 2.Medium 3.High) : ");

	 String priority=br.readLine();

	 return priority;

	 }


	 private static String getTickectNo() {

	 String id=""+(Math.random()*10000);

	 return id;

	 }

	 private static TicketBean getData() throws IOException

	 {

	 String ticketDescription;

	 String ticketno = getTickectNo();

	 String ticketCategoryId = tc.getTicketCategoryId();

	 System.out.println("Enter Description related to issue");

	 do {

	 ticketDescription = br.readLine();

	 }while(ticketDescription.length()==0);

	 String ticketPriority = getPriority();

	 return ticketBean = new TicketBean(ticketno,ticketCategoryId,ticketDescription,ticketPriority);

	 }


	}

	
	

	


