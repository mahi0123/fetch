package com.cg.tms.service;

import java.util.List;

import com.cg.tms.dao.TicketDAOImpl;
import com.cg.tms.dao.TicketDao;
import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;

public  class  TicketService_Impl implements TicketService{

	TicketDao td = new TicketDAOImpl();

	@Override
	public boolean raiseNewTicket(TicketBean ticketBean) {
		// TODO Auto-generated method stub
		return td.raiseNewTicket(ticketBean);
	}

	@Override
	public List<TicketCategory> listTicketCategory() {
		// TODO Auto-generated method stub


      return td.ListTicketCategory();
	}
	
	
}






























