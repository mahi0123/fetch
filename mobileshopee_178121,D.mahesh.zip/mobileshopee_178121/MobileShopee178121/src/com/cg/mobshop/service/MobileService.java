package com.cg.mobshop.service;

import java.util.List;

import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.exception.MobileShopException;
//interface of mobile service
public interface MobileService {

	public List<Mobiles> getMobileList() throws MobileShopException;
	public List<Mobiles> deleteMobile(int mobcode) throws MobileShopException;
	public List<Mobiles> SortList(int criteria) throws MobileShopException;
}
