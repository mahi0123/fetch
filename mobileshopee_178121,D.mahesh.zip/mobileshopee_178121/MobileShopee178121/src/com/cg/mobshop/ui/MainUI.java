package com.cg.mobshop.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.exception.MobileShopException;
import com.cg.mobshop.service.MobileService;
import com.cg.mobshop.service.MobileServiceImpl;

public class MainUI {
	
	
	public static MobileService mobService = new MobileServiceImpl();
	public static Scanner sc = new Scanner(System.in);
	static boolean res=false;
	
	//main method 
	public static void main(String[] args)  {
		try{
			
			//do while loop
			do{
				System.out.println();
				System.out.println("***************************Welcome to Mobile Shopee**********************");
				List<Mobiles> mobi = mobService.getMobileList();
				for(Mobiles mob1: mobi){
					System.out.println(mob1);
				}
				System.out.println("1.Sorting\n2.Delete\n3.Exit\n");
				
				switch(sc.nextInt()){
				
				case 1:
					System.out.println("sorting ");
					sorting();
					break;
				case 2:
					System.out.println("delete");
					delete();
					break;
				case 3:
					System.out.println("existed out");
					System.exit(0);
				
				break;
				default:System.out.println("Enter  from 1 to 3");
				break;
				}
			}while(res==false);
		}catch(MobileShopException msg){
			msg.getMessage();
		}
		
	}
	//creating sorting method
	public static void sorting() throws MobileShopException {
		System.out.println("1.Mobile Name\n2.Mobile Price\n3.Mobile Id");
		int criteria = sc.nextInt();
		List<Mobiles> mobiles = mobService.SortList(criteria);
		for(Mobiles mobile:mobiles){
			System.out.println(mobile);
		}
	}
     //create delete method
	public static void delete() throws MobileShopException {
		System.out.println("Enter the mobile id to delete");
		int mobcode = sc.nextInt();
		List<Mobiles> mobiles = mobService.deleteMobile(mobcode);
		for(Mobiles mobile:mobiles){
			System.out.println(mobile);
		}
	}

}
