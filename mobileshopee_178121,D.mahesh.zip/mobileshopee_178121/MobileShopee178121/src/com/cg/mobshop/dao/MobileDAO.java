package com.cg.mobshop.dao;

import java.util.List;

import com.cg.mobshop.dto.*;
import com.cg.mobshop.exception.MobileShopException;

 // interface of mobile dao
public interface MobileDAO {

	public List<Mobiles> getMobileList() throws MobileShopException;
	public List<Mobiles> deleteMobile(int mobcode) throws MobileShopException;
	public List<Mobiles> SortList(int criteria) throws MobileShopException;
}
