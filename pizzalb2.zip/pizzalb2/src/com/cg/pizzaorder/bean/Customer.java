package com.cg.pizzaorder.bean;

import java.time.LocalDate;

public class Customer {
	
	private int customerId;
	private String custName;
	private String address;
	private String phone;
	private String topping;
	private LocalDate date;
	private double totalPrice;
	
	
	public Customer(int customerId, String custName, String address, String phone, String topping, LocalDate date,
			double totalPrice) {
		super();
		this.customerId = customerId;
		this.custName = custName;
		this.address = address;
		this.phone = phone;
		this.topping = topping;
		this.date = date;
		this.totalPrice = totalPrice;
	}


	public String getTopping() {
		return topping;
	}


	public void setTopping(String topping) {
		this.topping = topping;
	}


	public LocalDate getDate() {
		return date;
	}


	public void setDate(LocalDate date) {
		this.date = date;
	}


	public double getTotalPrice() {
		return totalPrice;
	}


	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}


	public Customer(String custName, String address, String phone,String topping,LocalDate date,double totalPrice) {
		
		this.custName = custName;
		this.address = address;
		this.phone = phone;
		this.topping = topping;
		this.date = date;
		this.totalPrice=totalPrice;
	}


	public int getCustomerId() {
		return customerId;
	}


	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}


	public String getCustName() {
		return custName;
	}


	public void setCustName(String custName) {
		this.custName = custName;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getPhone() {
		return phone;
	}


	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	

}
