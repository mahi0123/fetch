package com.cg.pizzaorder.service;

import java.util.Date;
import java.util.regex.Pattern;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.dao.PizzaOrderDAO;

public class PizzaOrderService implements IPizzaOrderService {

	static boolean res=false;
	static PizzaOrderDAO pdao=null;
	
	private int generateOrderId(){
		int n=(int)(Math.random()*10000);
		return n;
	}
	private int generateCustomerId(){
		int m=(int)(Math.random()*10000);
		return m;
	}
	
	
	@Override
	public int placeOrder(Customer customer,PizzaOrder pizza) {
		
		pizza.setOrderId(generateOrderId());
		pizza.setCustomerId(generateCustomerId());
		customer.setCustomerId(generateCustomerId());
		pdao=new PizzaOrderDAO();
		return pdao.placeOrder(customer, pizza);
	}

	@Override
	public PizzaOrder getOrderDetails(int orderId) {
		pdao=new PizzaOrderDAO();
		return pdao.getOrderDetails(orderId);
	}
	
	@Override
	public boolean validateCustName(String custname) {
		if(custname==null ||custname.equals(null))
		{
			throw new ArithmeticException("Name is null");
		}
		if(!Pattern.compile("^[A-Z][a-z]{3,}").matcher(custname).find())
		{
			throw new ArithmeticException("Enter the proper format");
		}
		
		return true;
	}

	@Override
	public boolean validateAddress(String address) {
		if(address==null ||address.equals(null))
		{
			throw new ArithmeticException("Address is null");
		}
		if(!Pattern.compile("^[A-Z a-z 0-9]{5,}").matcher(address).find())
		{
			throw new ArithmeticException("Enter the proper format");
		}
		
		return true;
	}

	@Override
	public boolean validatePhone(String phone) {
		if(phone==null ||phone.equals(null))
		{
			throw new ArithmeticException("Phone number is null");
		}
		if(!Pattern.compile("^[6-9]{1}[0-9]{9}").matcher(phone).find())
		{
			throw new ArithmeticException("Enter the proper format");
		}
		
		return true;
	}

	@Override
	public boolean validateTopping(String topping) {
		if(topping==null ||topping.equals(null))
		{
			throw new ArithmeticException("Topping is null");
		}
		if(!((topping.equalsIgnoreCase("capsicum")) || (topping.equalsIgnoreCase("mushroom")) ||
				(topping.equalsIgnoreCase("jalapeno")) || (topping.equalsIgnoreCase("paneer"))))
		{
			throw new ArithmeticException("Select the topping which is available");
		}
		
		return true;
	}
	

	
	
}
