package com.cg.pizzaorder.dao;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;

public class PizzaOrderDAO implements IPizzaOrderDAO {
	
	static Map<Integer, PizzaOrder> pizzaEntry=new HashMap<>();
	static Map<Integer,Customer> customerEntry=new HashMap<>();

	public int placeOrder(Customer customer,PizzaOrder pizza) {
		
		pizzaEntry.put(pizza.getOrderId(), pizza);
		customerEntry.put(customer.getCustomerId(), customer);
		return pizza.getOrderId();
		
	}

	@Override
	public PizzaOrder getOrderDetails(int orderId) {
		Collection<PizzaOrder> plist=pizzaEntry.values();
		PizzaOrder p=pizzaEntry.get(orderId);
		
		Collection<Customer> clist=customerEntry.values();
		
		System.out.println("order Id : "+p.getOrderId());
		System.out.println("Customer Id : "+p.getCustomerId());
		System.out.println("Total Price : "+p.getTotalPrice());
		
		
		for(Customer entry:clist ) {

            System.out.println("Customer Name : "+entry.getCustName());
            System.out.println("Customer Address : "+entry.getAddress());
            System.out.println("Phone number : "+entry.getPhone());
            System.out.println("Topping : "+entry.getTopping());
            System.out.println("Order date :"+entry.getDate());
        }
		return p;
		
	}

}
