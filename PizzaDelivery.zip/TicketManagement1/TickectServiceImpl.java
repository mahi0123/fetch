package com.cg.tms.service;

import java.time.LocalDate;
import java.time.LocalDateTime;

import com.cg.tms.dao.DaoImpl;
import com.cg.tms.dao.IDao;
import com.cg.tms.dto.TicketBean;

public class TickectServiceImpl implements ITicketService{
static IDao idao= null;
	
	private int generateTicketNo(){
		return (int)((Math.random())*10000);
	} 
	
	public int raiseATicket(TicketBean t) {
		idao = new DaoImpl();
		t.setTicketNo(generateTicketNo());
		t.setTicketStatus("NEW");
		t.setDate(LocalDateTime.now());
		return idao.raiseATicket(t);
	}

}
