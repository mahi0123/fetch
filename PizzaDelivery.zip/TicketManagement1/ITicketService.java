package com.cg.tms.service;

import com.cg.tms.dto.TicketBean;

public interface ITicketService {

	int raiseATicket(TicketBean t);
	
}
