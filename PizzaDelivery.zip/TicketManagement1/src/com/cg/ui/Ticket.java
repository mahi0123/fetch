package com.cg.ui;

public class Ticket {
	public static void main(String[] args) {
		
		
		
	}

}
