package com.cg.tms.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.tms.dto.TicketBean;
public class DaoImpl implements IDao {

	static Map<Integer, TicketBean> map = new HashMap<Integer, TicketBean>();
	
	@Override
	public int raiseATicket(TicketBean t) {
		
		map.put(t.getTicketNo(), t);
		System.out.println(map);
		return t.getTicketNo();
		
	}

}
