package com.cg.tms.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class TicketBean {

private int ticketNo;
private String ticketCategoryId;
private String ticketDescription;
private String ticketPriority;
private String ticketStatus;
private LocalDateTime date;

public TicketBean() {
	// TODO Auto-generated constructor stub
}

public int getTicketNo() {
	return ticketNo;
}
public void setTicketNo(int ticketNo) {
	this.ticketNo = ticketNo;
}
public String getTicketCategoryId() {
	return ticketCategoryId;
}
public void setTicketCategoryId(String ticketCategoryId) {
	this.ticketCategoryId = ticketCategoryId;
}
public String getTicketDescription() {
	return ticketDescription;
}
public void setTicketDescription(String ticketDescription) {
	this.ticketDescription = ticketDescription;
}
public String getTicketPriority() {
	return ticketPriority;
}
public void setTicketPriority(String ticketPriority) {
	this.ticketPriority = ticketPriority;
}
public String getTicketStatus() {
	return ticketStatus;
}
public void setTicketStatus(String ticketStatus) {
	this.ticketStatus = ticketStatus;
}
public LocalDateTime getDate() {
	return date;
}
public void setDate(LocalDateTime date) {
	this.date = date;
}
public TicketBean(String ticketDescription,
		String ticketPriority) {
	
	this.ticketDescription = ticketDescription;
	this.ticketPriority = ticketPriority;
	
}
	

	
}

//-----------------------------------------------------------------------------

class TicketCategory{
	
	private String ticketCategoryId;
	private String categoryName;
	
	public String getTicketCategoryId() {
		return ticketCategoryId;
	}
	public void setTicketCategoryId(String ticketCategoryId) {
		this.ticketCategoryId = ticketCategoryId;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	
	@Override
	public String toString() {
		return "TicketCategory [ticketCategoryId=" + ticketCategoryId
				+ ", categoryName=" + categoryName + "]";
	}
	public TicketCategory(String ticketCategoryId, String categoryName) {
		super();
		this.ticketCategoryId = ticketCategoryId;
		this.categoryName = categoryName;
	}
	
	
	

	
}
