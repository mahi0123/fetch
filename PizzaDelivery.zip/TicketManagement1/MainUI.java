package com.cg.tms.ui;

import java.time.LocalDate;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.service.ITicketService;
import com.cg.tms.service.TickectServiceImpl;
import com.cg.tms.util.Util;

public class MainUI {
	static Scanner sc1 = new Scanner(System.in);
	static int opt1,opt2;
	static Util util = null;
	static ITicketService iserv= null;
	static TicketBean b = new TicketBean();
	static String ticketCategoryId,desc,priority,status;
	static LocalDate date;
	
	public static void main(String[] args) {
		
		do{
		System.out.println("WELCOME TO ITIMD HELP DESK");
		System.out.println();
		System.out.println("Press 1. RAISE A TICKET \n 2. EXIT FROM THE SYSYEM");
		opt1=sc1.nextInt();
		
		while(!(opt1==1 || opt1==2)){
			System.out.println("choose on your requirement");
			opt1=sc1.nextInt();
		}
		
		switch(opt1){
		
		case 1:
			int TicketNumber=raiseATicket();	
			System.out.println("Ticket Number "+TicketNumber + " logged successfully at " +b.getDate());
		break;
		
			
		}	
		
	}while(opt1!=2);
	}

	private static int raiseATicket() {	
		iserv = new TickectServiceImpl();
		util = new Util();
		Map<String, String> info = util.getTicketCategoryEntries();
		Collection<String> col = info.values();
		System.out.println("select the ticket category");
		int i=0;
		for(String opt:col){
			System.out.println(++i +":" +opt);	
		}
			
		do{
		opt2=sc1.nextInt();
		if(opt2==1){
			b.setTicketCategoryId("tc001");	
		}
		else if(opt2==2){
			b.setTicketCategoryId("tc002");
		}
		else if(opt2 == 3){
			b.setTicketCategoryId("tc003");
		}
		
		else{
			System.out.println("Enter from the available");
		}
	}while(!(opt2==1||opt2==2||opt2==3));
		
		System.out.println("Enter Ticket Description");
		desc=sc1.next();
		
		System.out.println("Enter priority");
		priority = sc1.next();
		
		while(!(priority.equalsIgnoreCase("low")||priority.equalsIgnoreCase("medium")||priority.equalsIgnoreCase("high"))){
			System.out.println("Enter only either 'low' 'medium' 'high'");
			priority = sc1.next();
		}
		
		
		b=new TicketBean(desc, priority);
		return iserv.raiseATicket(b);
	}
	
	
	
		
	
}
	
