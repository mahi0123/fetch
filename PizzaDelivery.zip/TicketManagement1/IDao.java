package com.cg.tms.dao;

import com.cg.tms.dto.TicketBean;

public interface IDao {

	int raiseATicket(TicketBean t);
}
