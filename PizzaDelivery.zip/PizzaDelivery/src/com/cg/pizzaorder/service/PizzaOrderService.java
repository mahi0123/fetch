package com.cg.pizzaorder.service;

import com.cg.pizzaorder.bean.*;
import com.cg.pizzaorder.dao.*;
import com.cg.pizzaorder.exception.PizzaException;

public class PizzaOrderService implements IPizzaOrderService {
	IPizzaOrderDAO pizzaDao=new PizzaOrderDAO();
	
	
	@Override
	public int GenOrderId() {
		
		int orderId=(int) (Math.random()*1000);
		return orderId;
	}
	
	
	@Override
	public int GenCustId()
	{
		int custId=(int)(Math.random()*1000);
		return custId;
	}
	
	@Override
	public int placeOder(Customer customer, PizzaOrder pizza) throws PizzaException {
		// TODO Auto-generated method stub
		int orderId=pizzaDao.placeOder(customer, pizza);
		return orderId;
	}

	@Override
	public PizzaOrder getOderDetails(int orderid) throws PizzaException {
		// TODO Auto-generated method stub
		
		
		return pizzaDao.getOderDetails(orderid);
	}


	@Override
	public boolean validatePhone(String mobile) throws PizzaException {
		// TODO Auto-generated method stub
		boolean ch=false;
		boolean check=mobile.matches(mobilePattern);
		if(check)
			return ch=check;
		else {
			throw new PizzaException("Mobile number  is Wrong");
		}
	}


}
