package com.cg.pizzaorder.dao;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import com.cg.pizzaorder.bean.*;
import com.cg.pizzaorder.exception.PizzaException;
import com.cg.pizzaorder.service.PizzaOrderService;

public class PizzaOrderDAO implements IPizzaOrderDAO{

	//map for orderid as key and pizza order as value
	Map<Integer,PizzaOrder> pizzaEntry =new ConcurrentHashMap<Integer, PizzaOrder>();
	
	//map for customer id as key and customer object as value
	Map<Integer,Customer> customerEntry =new ConcurrentHashMap<Integer, Customer>();
	
	
	@Override
	public int placeOder(Customer customer, PizzaOrder pizza) throws PizzaException {
		// TODO Auto-generated method stub
	
		pizzaEntry.put(pizza.getOrderId(), pizza);//putting pizza order to pizza map
		customerEntry.put(pizza.getCustomerId(), customer);//putting customer order to customer map.
		
		PizzaOrder p=pizzaEntry.get(pizza.getOrderId());
		if(p!=null)
			return pizza.getOrderId();
		else 
			return 0;
	}

	@Override
	public PizzaOrder getOderDetails(int orderId) throws PizzaException {
		// TODO Auto-generated method stub
		PizzaOrder po=pizzaEntry.get(orderId);
		if(po!=null)
			return po;
		else
			throw new PizzaException("Order id is not found");
	}
	//JUNIT Test cases
	//validating mobile number
	@ParameterizedTest
	@ValueSource(strings= {"1234567890","9876543210","4563219870"})
	void testValidateMobile(String mobileString) throws PizzaException
	{
		System.out.println("Parameter"+mobileString);
		PizzaOrderService ps=new PizzaOrderService();
		assertTrue(ps.validatePhone(mobileString));
	}
	
	//validating order id's
	@ParameterizedTest
	@ValueSource(ints= {12,145,123})
	void testOrderId(int orId) throws PizzaException {
		System.out.println("testing order ids");
		assertEquals(getOderDetails(orId),pizzaEntry.get(orId));
	}
	
	

}
