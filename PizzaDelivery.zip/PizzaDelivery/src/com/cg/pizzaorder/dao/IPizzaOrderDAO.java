package com.cg.pizzaorder.dao;

import com.cg.pizzaorder.bean.*;
import com.cg.pizzaorder.exception.PizzaException;

public interface IPizzaOrderDAO {
	public int placeOder(Customer customer, PizzaOrder pizza) throws PizzaException;
	public PizzaOrder getOderDetails(int orderId)throws PizzaException;
}
