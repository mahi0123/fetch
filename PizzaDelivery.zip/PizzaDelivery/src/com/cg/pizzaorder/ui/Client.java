package com.cg.pizzaorder.ui;

import java.io.*;
import java.time.LocalDate;

import com.cg.pizzaorder.bean.*;
import com.cg.pizzaorder.exception.PizzaException;
import com.cg.pizzaorder.service.*;

public class Client {

	public static void main(String[] args) throws NumberFormatException, IOException, PizzaException {
		// TODO Auto-generated method stub
		IPizzaOrderService service=new PizzaOrderService();
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		PizzaOrder pizza;
		Customer customer;
		int basePizzaPrice=350;
		int ch,orderId,customerId,totalPrice = 0;
		System.out.println("Enter any option:\n");
		System.out.println("1) Place Oder\n2) Display Order\n3) Exit ");
		ch=Integer.parseInt(br.readLine());
		do {
			switch(ch) {
			case 1: //when person enters the option 1
					System.out.println("Enter the name of the customer");
					String cusName=br.readLine();//John
					
					System.out.println("Enter customer address");
					String cusAddress=br.readLine();//Dallas
					
					System.out.println("Enter cutomer phone number");
					String cusPhone=br.readLine();//9784563210
					service.validatePhone(cusPhone);//validating mobile number
					
					System.out.println("Enter the type of pizza topings preffered");
					String topings=br.readLine();//Paneer
					
					if(topings.equals("Capsicum"))
					{
						totalPrice=basePizzaPrice+30;
					}
					else if(topings.equals("Mushroom"))
					{
						totalPrice=basePizzaPrice+50;
					}
					else if(topings.equals("Jalapeno"))
					{
						totalPrice=basePizzaPrice+70;
					}
					else if(topings.equals("Paneer")) 
						totalPrice =basePizzaPrice+85;
					
					System.out.println(totalPrice);
					System.out.println("Order date "+LocalDate.now());
					customer=new Customer(cusName, cusAddress, cusPhone);
					orderId=service.GenOrderId();//generate the order id
					customerId=service.GenCustId();//generates the customer id
					pizza=new PizzaOrder(orderId, customerId, totalPrice );
					System.out.println("Pizza Order successfully placed with Order Id "+service.placeOder(customer, pizza));//adds to static DB and return the order id 
					break;
			case 2: //getting order detils from order id
					System.out.println("Enter the order id :");
					orderId=Integer.parseInt(br.readLine());
					System.out.println("Order details are :\n\n"+service.getOderDetails(orderId));
					break;
		
			case 3: System.exit(0);
			
			default : System.out.println("Enter correct choice");
			}
			
		System.out.println("1) Place Oder\n2) Display Order\n3) Exit ");
		ch=Integer.parseInt(br.readLine());	
			
		}while(ch!=3);
		
	}

}
