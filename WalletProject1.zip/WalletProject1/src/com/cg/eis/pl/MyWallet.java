package com.cg.eis.pl;

import java.util.Map;

import com.cg.eis.bean.Account;
import com.cg.eis.service.*;
import com.cg.eis.service.WalletServiceImpl;

public class MyWallet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WalletService service=new WalletServiceImpl();
		
		Account ob1= new Account(100,"Ram",111111111,25000.00);
		
		boolean added=service.createAccount(ob1);
		System.out.println("account added"+added);
		
		Account ob2= new Account(101,"sham",22222222,35000.00);
		added=service.createAccount(ob2);
		System.out.println("account added"+added);
		
		Map<Integer, Account>allac=service.getAllAccount();
		System.out.println(allac);
		
		Account myac=service.getAccountBymobile(22222222);
		System.out.println(myac);
	}

}
                                                          