package com.cg.eis.bean;

public class Account {
	
	private int accno;
	private String custName;
	private int mobileNo;
	private double balance;
	
	public Account() {
		// TODO Auto-generated constructor stub
	}
	public Account(int accno, String custName, int mobileNo, double balance) {
		super();
		this.accno = accno;
		this.custName = custName;
		this.mobileNo = mobileNo;
		this.balance = balance;
	}

	public int getAccno() {
		return accno;
	}

	public void setAccno(int accno) {
		this.accno = accno;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public int getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Account [accno=" + accno + ", custName=" + custName + ", mobileNo=" + mobileNo + ", balance=" + balance
				+ "]";
	}
	
	
}
