package com.cg.eis.service;

import java.util.Map;

import com.cg.eis.bean.Account;
import com.cg.eis.dao.AccountDao;
import com.cg.eis.dao.AccountDaoImpl;

public class WalletServiceImpl implements WalletService{
	
	/*
	 * 
	 * Wallet service is connecting to accountDao
	 * 
	 * 
	 */
	AccountDao accountdao= new AccountDaoImpl();

	@Override
	public boolean validateMobile(String mobile) {
		
		return false;
	}         

	@Override
	public boolean createAccount(Account ac) {
		// TODO Auto-generated method stub
		return accountdao.createAccount(ac);
	}

	@Override
	public Account getAccountBymobile(int mobileNo) {
		// TODO Auto-generated method stub
		return accountdao.getAccountBymobile(mobileNo);
	}

	@Override
	public Map<Integer, Account> getAllAccount() {
		// TODO Auto-generated method stub
		return accountdao.getAllAccount();
	}
	
	

}
