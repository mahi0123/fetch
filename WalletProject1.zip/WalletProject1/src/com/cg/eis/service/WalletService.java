package com.cg.eis.service;

import java.util.Map;

import com.cg.eis.bean.Account;

public interface WalletService {

	String mobilePattern="[0-9] {10}";
	
	public boolean validateMobile(String mobile);
	
	public boolean createAccount(Account ac);
	
	public Account getAccountBymobile(int mobileNo);
	
	public Map<Integer,Account>getAllAccount();
	
}
