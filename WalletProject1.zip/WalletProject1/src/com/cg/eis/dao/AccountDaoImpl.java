package com.cg.eis.dao;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.cg.eis.bean.Account;

public class AccountDaoImpl implements AccountDao {
	
	
	//wallet account database
	Map<Integer,Account>WalletAccounts= new ConcurrentHashMap<>();
	
	
	/*
	 * 
	 * method to insert new account in a database
	 * 
	 */
	@Override
	public boolean createAccount(Account ac) {
		WalletAccounts.put(ac.getMobileNo(), ac);
		Account ac1=WalletAccounts.get(ac.getMobileNo());
		if(ac1!=null)
			
		return true;
		else
			return false;
	
	}
	
	/*
	 * 
	 * Method to retrieve account by mobile no from database
	 * 
	 * 
	 */

	@Override
	public Account getAccountBymobile(int mobileNo) {
		Account ac=WalletAccounts.get(mobileNo);
		if(ac!=null)
			return ac;
		else
		return null;
	}

	@Override
	public Map<Integer, Account> getAllAccount() {
		
		return WalletAccounts;
	}

}
