package com.cg.mypackage.dao;

import javax.persistence.EntityManager;

import com.cg.mypackage.Author;

public class AuthorDAOImpl implements AuthorDAO {

	private EntityManager em = JPAUtil.getEntityManager();
	
	@Override
	public void save(Author author) {
		//TODO: Handle Exceptions
		em.getTransaction().begin();
		em.persist(author);
		em.getTransaction().commit();
		System.out.println("Record saved!");
	}

	@Override
	public Author findById(Integer authorId) {
		// TODO Auto-generated method stub
		//TODO: Handle Exceptions
		return em.find(Author.class, authorId);
	}

	@Override
	public void update(Author author) {
		//TODO: Handle Exceptions
		em.getTransaction().begin();
		em.merge(author);
		em.getTransaction().commit();
		System.out.println("Record Updated!");
	}

	@Override
	public void delete(Integer authorId) {
		//TODO: Handle Exceptions
		Author st = findById(authorId);
		em.getTransaction().begin();
		em.remove(st);
		em.getTransaction().commit();
		System.out.println("Record Removed");
		
	}

}
