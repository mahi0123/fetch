package com.cg.mypackage.dao;
import com.cg.mypackage.Author;
public class Main {
 public static void main(String[] args) {
 AuthorDAO dao = new AuthorDAOImpl();
 //Test CREATE
 System.out.println("Creating record");
 Author s1 = new Author();
 s1.setFirstName("mounika");
 s1.setLastName("singupuram");
 s1.setMiddleName(" ");
 s1.setAuthorId(101);
 s1.setPhoneNo(9618098601L);
 dao.save(s1);
 System.out.println();
 System.out.println("Updating record");
 s1.setFirstName("mounika");
 dao.update(s1);

 System.out.println();
 System.out.println("Finding record");
 Author s2 = dao.findById(101);
 System.out.println("Found: ");
 System.out.println("Author Id : "+s2.getAuthorId());
 System.out.println("First Name : "+s2.getFirstName());
 System.out.println("Middle Name : "+s2.getMiddleName());
 System.out.println("Last Name : "+s2.getLastName());
 System.out.println("Phone : "+s2.getPhoneNo());


 System.out.println();
 System.out.println();
 System.out.println("Deleting a record");
 
 dao.delete(101);
 try {
 System.out.println("Find after delete (Beware of Exceptions!)");
 s2 = dao.findById(101);
 System.out.println("Found: "+s2.getFirstName()+" "+s2.getLastName());
 }
 catch(Exception e)
 {
  System.err.println("Record not Found "+e.getMessage());
 }

 }

}
