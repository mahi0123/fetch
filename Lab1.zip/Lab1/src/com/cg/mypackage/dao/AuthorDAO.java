package com.cg.mypackage.dao;

import com.cg.mypackage.Author;

public interface AuthorDAO {
	//CREATE method
	void save(Author author); 
	//RETRIEVE
	Author findById(Integer authorId);
	
	//UPDATE
	void update(Author author);
	
	//DELETE
	void delete(Integer authorId);
	
}